# Fleet window drafts 3 and 4 for Paper (2026-11-21)

Built from the game with tools/paper-sync (dump2html.py): every text a text layer, every box a box layer, only pictures as images.
Each window was checked against the game's pixels: all under 1% of pixels off by more than 60/255.

- draft_3/: artboard "Fleet window - draft 3 - two columns - 2026-11-21". Pieces in order: 00_notes, 01_windows.
- draft_4/: artboard "Fleet window - draft 4 - one column - 2026-11-21". Pieces in order: 00_notes, 01_screen, 02_windows.
- draft_3.html, draft_4.html: each artboard's children in one document.
- img/: the pictures. The HTML points at paper-asset:///Users/paulgazagnaire/Repos/paper-exports/2026-11-21-fleets/img/

Artboard: background #111214, vertical auto layout, padding 48, gap 48, width hugs its content.
